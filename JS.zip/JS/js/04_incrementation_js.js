/*---------------Incrémentation------------------------------------------------

C' est une opération qui consiste a toujours ajouter "1" ( et par extention toute valeur entière fixée ) a un compteur.
L' opération inverse est la désincrémentation ( retirer "1" au compteur)
L' opérateur d' incrément ajoute une unité a son opérande, et renvoie une valeur.

*****************incrémentation*******************

var nb1 = 1;
nb1 = nb1 + 1;
J' augmente sa valeur de "1"
console.log(nb1);
document.write(nb1);
                        Meme opération en simplifiée

nb1++
console.log(nb1);
document.write(nb1);

                        Encore une autre ecriture simplifiée

++nb1;
console.log(nb1);
document.write(nb1);

------------------------Decrementation-------------------------

nb1 = nb1 - 1;
console.log(nb1 + "<br>");
document.write(nb1 + "<br>");

*/

var nb1 = 1;
nb1 = nb1 + 1;
console.log(nb1);
document.write(nb1 + "<br>");

nb1++
console.log(nb1);
document.write(nb1 + "<br>");

++nb1;
console.log(nb1);
document.write(nb1 + "<br>");

nb1 = nb1 - 1;
console.log(nb1 + "<br>");
document.write(nb1 + "<br>");
