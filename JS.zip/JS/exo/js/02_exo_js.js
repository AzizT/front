function surfaceCercle(){
    var rayon;
    var rayon = prompt("Entre le rayon du cercle");
    resultat = 3.14 * rayon * rayon;
    alert("La surface du cercle est de " + resultat);
}
/*----------------correction sandra---------------------------
function surfaceCercle(){
    var rayon = parsefloat(prompt("Entrez le rayon du cercle : "));
    return 3.14 * rayon * rayon;
}




*/