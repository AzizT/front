var nb1 = 5;

var nb2 = 3;
/*
nombre1=nombre1+nombre2;
nombre2=nombre1-nombre2;
nombre1=nombre1-nombre2;

console.log(nombre1);

console.log(nombre2);

-----------------solution 1

nb1= 5 - 2;
nb2= 3+2;
console.log(nb1);
console.log(nb2);

--------------------solution 2
*/
var vide = nb1;
nb1 = nb2;
nb2 = vide;
console.log(nb1);
console.log(nb2);








