var nom = prompt('Salut; quel est ton nom ?', 'ecris ton nom');
var prenom = prompt('Quel est ton nom ?', 'ecris ton prénom');
alert("Bienvenue a toi " + nom + " " + prenom);