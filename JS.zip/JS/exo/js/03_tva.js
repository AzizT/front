var prixHt;
prixHt = Number(prompt("Ecrivez la somme en HT"));
var ttc = prixHt * 1.2;
alert("Le prix TTC est de " + ttc);