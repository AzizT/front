var celsius;
var farhenheit;
celsius = Number(prompt(" Saisissez la température en degrés Celsius "));
var farhenheit = 1.8 * celsius + 32;
alert(" La température équivalente en farhenheit est de " + farhenheit);