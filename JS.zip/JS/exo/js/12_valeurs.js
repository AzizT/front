var nb1 =Number(prompt("Entrez nb1"));
var nb2 =Number(prompt("Entrez nb2"));
var nb3 =Number(prompt("Entrez nb3"));

if(nb1>nb2){
    alert(nb1 = nb3*2);
    
}else{
    alert(nb1=nb1+1);
    
}
/*********************Corrigé Sandra***************** 

var nb1 =Number(prompt("Entrez nb1"));
var nb2 =Number(prompt("Entrez nb2"));
var nb3 =Number(prompt("Entrez nb3"));

*/