// alert("coucou");

var moyenne_maths = Number(prompt("Ecrivez votre moyenne en Math"));
var moyenne_français = Number(prompt("Ecrivez votre moyenne en Français"));
var moyenne_histoire = Number(prompt("Ecrivez votre moyenne en Histoire"));
var moyenne_anglais = Number(prompt("Ecrivez votre moyenne en Anglais"));

var moyenne_generale = (moyenne_maths + moyenne_français + moyenne_histoire + moyenne_anglais) / 4;

// if(Number = TRUE){}else{
//     document.write("Vous ne pouvez ecrire en caractères d' alphabet, mais uniquement des chiffres");
//     }

    if(moyenne_generale<=5){
        document.write("Vous etes médiocre car votre moyenne de " + moyenne_generale + " n'est pas bon");
    }else if(moyenne_generale>5 && moyenne_generale<10){
        document.write("Vous etes pas reçu, car votre moyenne de " + moyenne_generale + " est insuffisant");
    }else if(moyenne_generale>=10 && moyenne_generale<=12){
        document.write("Vous etes reçu,votre moyenne de " + moyenne_generale + " nous a convaincu");
    }else if(moyenne_generale>12 && moyenne_generale<=16){
        document.write(" votre moyenne de " + moyenne_generale + " de moyenne montre que vous êtes un bon élève");
    }else if(moyenne_generale>16 && moyenne_generale <=20){
        document.write("Vous avez un très bon niveau avec une moyenne de " + moyenne_generale);
    }else{
        document.write("Erreur, votre moyenne ne peut exceder 20. Veuillez recommencer !");
    }

